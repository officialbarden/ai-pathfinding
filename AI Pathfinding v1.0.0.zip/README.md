# ai-pathfinding
This datapack implements Pathfinding for your Custom Mob!
